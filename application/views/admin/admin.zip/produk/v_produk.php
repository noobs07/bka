<div class="content-wrapper">
	<div class="content-header"></div>

	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-12">
					<div class="card">
						<div class="card-header">
							<h2 class="card-title">Daftar Produk</h2>
							<div class="float-right">
								<button class="btn btn-warning btn-sm" onclick="refreshTable()">Refresh</button>
								&nbsp;
								<button class="btn btn-success btn-sm" data-toggle="modal" data-target="#form_modal">Tambah</button>
							</div>
						</div>
						<!-- /.card-header -->
						<div class="card-body">
							<table id="table" class="table table-bordered table-hover" style="width:100%"></table>
						</div>
						<!-- /.card-body -->
					</div>
					<!-- /.card -->

				</div>
				<!-- /.col -->
			</div>
			<!-- /.row -->
		</div>
		<!-- /.container-fluid -->
	</section>
</div>a